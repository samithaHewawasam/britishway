<div class="main-background">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 report" id="excel_form">
         <div class="login-form" style="max-width: 100% ! important;">
          <div class="login-content">
	<table class='table'>
	<tr><th>ATI Name</th><th>Course Count</th><th>Subject count</th><th>Packet count</th><th>Students Sat count</th></tr>
	<tr ng-repeat="report in reports">
	<td>{{($last) ? "Summary" : report.ati_name}}</td>
	<td>{{report.course_count}}</td>
	<td>{{report.sub_count}}</td>
	<td>{{report.packet_count}}</td>
	<td>{{report.student_sat_count}}</td>
	</tr>
	</table>
	  </div>
        </div>
      </div>
    </div>
  </div>
</div> 

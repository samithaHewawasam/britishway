<div class="main-background">
  <div class="container">
    <div class="row">
      <div class="col-md-12 inner_area">
        <div class="login-form">
          <div class="login-content">
          <form name=subject_panel_form novalidate>
            <div class="form-group col-lg-12 col-xs-12" ng-class="{ 'has-error': subject_panel_form.Course.$invalid &&!subject_panel_form.Course.$pristine}">
              <label>Course</label>
              <select ng-options="course.id as course.course_code for course in courses" ng-change="courseSelect(subject_panel.Course)" ng-model="subject_panel.Course" class="form-control" name=Course  ng-required="true"></select>
            </div>
            <div class="form-group col-lg-12 col-xs-12" ng-class="{ 'has-error': subject_panel_form.Subject.$invalid &&!subject_panel_form.Subject.$pristine}">
              <label>Subject</label>
              <select ng-options="subject.id as subject.subject_name for subject in subjects" ng-model="subject_panel.Subject" class="form-control" name=Subject  ng-required="true"></select>
            </div>
            <div class="form-group col-lg-12 col-xs-12" ng-class="{ 'has-error': subject_panel_form.panel_code.$invalid &&!subject_panel_form.panel_code.$pristine}">
              <label>Panel</label>
              <input type="text" class="form-control" name=panel_code ng-model="subject_panel.panel_code" ng-required="true">
            </div>
            <div class="form-group col-lg-12"><a href="javascript:void(0)" ng-disabled="subject_panel_form.$invalid" class="btn create-btn" ng-click="savesubject_panel(subject_panel)">Create</a></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

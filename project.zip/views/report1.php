<div class="main-background">
  <div class="container">
    <div class="row">
      <div class="col-md-12 report">
         <div class="login-form">
          <div class="login-content">
	<table class='table'>
	<tr><th>Course Name</th><th>Ati Name</th><th>Subject Name</th><th>Packet</th><th>Answer Sheets</th></tr>
	<tr ng-repeat="report in reports">
	<td>{{report.course_name}}</td>
	<td>{{report.ati_name}}</td>
	<td>{{report.subject_name}}</td>
	<td>{{report.packet}}</td>
	<td>{{report.students_sat}}</td>
	</tr>
	</table>
	  </div>
        </div>
      </div>
    </div>
  </div>
</div>

		<div class="main-background">
		 	<div class="container">
		    	<div class="row">
		        	<div class="col-md-12 ">

		        	<!--login_form start-->
		          		<div class="login-form">
		          			<div class="login-content" >
		                    	<form name="login_form" novalidate>
			                        <div class="section-title">
			                            <h3>LogIn to your Account</h3>
			                        </div>

			                        <div class="textbox-wrap">
			                            <div class="input-group" ng-class="{ 'has-error': login_form.username.$invalid &&!login_form.username.$pristine}">
			                                <span class="input-group-addon "><i class="fa fa-user icon-color"></i></span>
			                                <input type="text"  name="username" ng-model="login.user_name" class="form-control" placeholder="Username" ng-required="true">
			                            </div>
			                        </div>

			                        <div class="textbox-wrap">
			                            <div class="input-group" ng-class="{ 'has-error': login_form.password.$invalid && !login_form.password.$pristine}">
			                                <span class="input-group-addon"><i class="fa fa-key icon-color"></i></span>
			                                <input type="password"  name="password" ng-model="login.password" class="form-control " placeholder="Password" ng-required="true">
			                            </div>
			                            <p ng-show="login_form.password.$error.minlength" class="help-block ">Must be at least 8 characters long</p>

			                        </div>

			                        <div class="login-form-action clearfix">
			                            <div class="checkbox pull-left">
			                                <div class="custom-checkbox">
												<input type='checkbox' name='thing' value='valuable' id="thing"/>
												<!--<label for="thing"></label>-->
			                                </div>
			                                <span class="checkbox-text pull-left">&nbsp;Remember Me</span>
			                            </div>
			                            <button type="submit" ng-click="loginForm(login)" data-placement="top-right" ng-disabled="login_form.$invalid || username=='' || password=='' " class="btn btn-success pull-right green-btn">LogIn &nbsp; <i class="fa fa-chevron-right"></i></button>
			                        </div>
		                    	</form>
		                    </div>
		                </div>
		            <!--login_form end-->





		        	</div>
		   		</div>
			</div>
		</div>

app.controller('indexController', ['$scope', 'dataService', '$filter', 'getData', 'Ajax', '$rootScope', function($scope, dataService, $filter, getData, Ajax, $rootScope) {

$scope.courses = getData.courses.data;
$scope.atis = getData.atis.data;
$scope.subjects = getData.subjects.data;
$scope.student_sats = getData.student_sats.data;
$rootScope.menus = dataService.get().menus;
$scope.aticourses = getData.aticourses.data;

$scope.courseSelect = function(course_id){
  $scope.subjects = $filter('subjects')(getData.subjects.data, course_id);
};

$scope.savestudents_sat = function(sat){

  Ajax.post({
    "url"   : "php/satStatus.php",
    "data"  : sat
  }).then(function(response){

    if(response.success == 1){
      alert("Updated");
      $scope.students_sat = "";
    }else{
      alert("Error found");
    }

  });

};

$scope.saveati_courses = function(ati_courses){

  Ajax.post({
    "url"   : "php/ati_courses.php",
    "data"  : ati_courses
  }).then(function(response){

    if(response.success == 1){
      alert("Added");
      $scope.students_sat = "";
    }else{
      alert("Error found");
    }

  });

};

}]);

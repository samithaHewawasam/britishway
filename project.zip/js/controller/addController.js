app.controller('addController', ['$scope', 'dataService', '$filter', 'Ajax', 'getData', function($scope, dataService, $filter, Ajax, getData) {

$scope.courses_filter = getData.courses.data;

$scope.saveati = function(){

  Ajax.post({
    "url"   : "php/add.php",
    "data"  : $scope.ati
  }).then(function(response){

    if(response.commit == 1){
      alert("Added");
      $scope.ati = {};
    }else{
      alert("Error found");
    }

  });

};

$scope.savecourses = function(){

  Ajax.post({
    "url"   : "php/add.php",
    "data"  : $scope.courses
  }).then(function(response){

    if(response.commit == 1){
      alert("Added");
      $scope.courses = {};
    }else{
      alert("Error found");
    }

  });

};

$scope.savesubjects = function(){

  Ajax.post({
    "url"   : "php/add.php",
    "data"  : $scope.subjects
  }).then(function(response){

    if(response.commit == 1){
      alert("Added");
      $scope.subjects = {};
    }else{
      alert("Error found");
    }

  });

};

}]);

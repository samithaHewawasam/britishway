<?php
include __DIR__ . '/dbh.php';
$rawData = file_get_contents("php://input");
$POST = json_decode($rawData, true);
if(!empty($POST))
$sat = $helper->execPrepare("INSERT INTO `students_sat`(`institute`, `Course`, `Subject`, `packet`, `students_sat`, `students_absent`) VALUES (?,?,?,?,?,?)", array($POST['institute'], $POST['Course'], $POST["Subject"], $POST["packet"], $POST["students_sat"], $POST["students_absent"]));

echo json_encode($sat);

?>

<?php
include __DIR__ . '/dbh.php';
$rawData = file_get_contents("php://input");
$POST = json_decode($rawData, true);
if(!empty($POST))
$sat = $helper->execPrepare("INSERT INTO `subject_panel`(`subject_id`, `panel_code`) VALUES (?,?)", array($POST['Subject'], $POST['panel_code']));

echo json_encode($sat);

?>

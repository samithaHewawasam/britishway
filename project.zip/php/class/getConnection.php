<?php

class getConnection
{

    private $db;
    private $sql;

        function __construct(PDO $connection)
    {
        $this->db = $connection;
    }

    public function prepareSelected($query, array $data)
    {

        try {

            $sql = $this->db->prepare($query);
            $sql->execute($data);
            return $sql->fetchALL(PDO::FETCH_OBJ);

        }
        catch (PDOException $ex) {

            return $ex->getMessage();

        }

    }

      public function execPrepare($query, array $data)
  {

    try {
        $sql = $this->db->prepare($query);
        $sql->execute($data);

        return array(
            'success' => $sql->rowCount()
        );
    }
    catch (PDOException $exception) {

        return array(
            'error' => $exception->getMessage()
        );
    }

  }

}

?>

<?php

class admin extends user{









}


?>

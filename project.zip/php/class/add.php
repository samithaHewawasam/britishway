<?php

class add extends database
{


    public function setAtis(array $params)
    {

        return parent::executeQuery($params);

    }

    public function setCourses(array $params)
    {

        return parent::executeQuery($params);

    }

    public function setSubjects(array $params)
    {

        return parent::executeQuery($params);

    }

}

?>
